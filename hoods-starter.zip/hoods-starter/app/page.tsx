"use client";

import { useEffect, useRef } from "react";
import mapboxgl from "mapbox-gl";

export default function Home() {
  const mapContainer = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<mapboxgl.Map | null>(null);

  useEffect(() => {
    if (!mapContainer.current || mapRef.current) return;

    const token = process.env.NEXT_PUBLIC_MAPBOX_TOKEN as string | undefined;
    if (!token) {
      console.error("Missing NEXT_PUBLIC_MAPBOX_TOKEN");
      return;
    }
    mapboxgl.accessToken = token;

    mapRef.current = new mapboxgl.Map({
      container: mapContainer.current,
      style: "mapbox://styles/mapbox/streets-v12",
      center: [-97.7431, 30.2672], // Austin, TX
      zoom: 10
    });

    return () => {
      mapRef.current?.remove();
      mapRef.current = null;
    };
  }, []);

  return (
    <main className="min-h-screen">
      <header className="hoods-header p-4 border-b border-black/10 flex items-center justify-between">
        <h1 className="text-2xl font-bold tracking-tight">Hoods</h1>
        <p className="text-sm opacity-90">Austin, TX — prototype</p>
      </header>

      <section className="p-4 grid gap-4">
        <div className="rounded-2xl border p-4">
          <h2 className="text-lg font-semibold mb-2">Map</h2>
          <div ref={mapContainer} className="w-full h-[70vh] rounded-xl border" />
        </div>
      </section>
    </main>
  );
}
