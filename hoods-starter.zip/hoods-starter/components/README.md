Place shared UI components here (e.g., sidebar, neighborhood list, filters).
